package cn.bidostar.ticserver.service;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.alibaba.fastjson.JSON;

import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;

import cn.bidostar.ticserver.CarApplication;
import cn.bidostar.ticserver.model.RequestCommonParamsDto;
import cn.bidostar.ticserver.netty.NettyClient;
import cn.bidostar.ticserver.utils.I;
import cn.bidostar.ticserver.utils.NetworkUtil;
import cn.bidostar.ticserver.utils.ServerApiUtils;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;

public class JobSchedulerService extends JobService {

    @Override
    public boolean onStartJob(JobParameters mJobParameters) {
        //唤醒设备
        /*Intent intent = new Intent("com.car.syswakeup");
        intent.putExtra("reason", "recordvideo");
        sendBroadcast(intent);*/
        I.e("JobSchedulerService","<<<<<<Write heartbeat>>>>>>>>>>>");
        byte[] requestBody = "[C1,6,866401020000050,2018-11-06 08:20:11,T101,0000,0,9454006107013879,89462035031800077547,460,0,9375#4293#-63,100]".getBytes();
        NettyClient.getInstance().sendMsgToServer(requestBody, new ChannelFutureListener() { //3
            @Override
            public void operationComplete(ChannelFuture future) {
                I.e("Write heartbeat successful");
            }
        });
        //ServerApiUtils.getInstance().headtBeat();
        /*try{
            String gpsurl =  CarApplication.getApplication().getServerUrlBase() + "/device/other";
            RequestParams params = new RequestParams(gpsurl);
            params.setAsJsonContent(true);
            params.setConnectTimeout(2*1000);//2秒超时
            RequestCommonParamsDto dto = new RequestCommonParamsDto();
            dto.setDeviceId(CarApplication.getApplication().getDeviceIMEI());
            String jsonData = JSON.toJSONString(dto);
            params.setBodyContent(jsonData);
            x.http().post(params, new Callback.CommonCallback<String>(){
                @Override
                public void onSuccess(String result) {
                }

                @Override
                public void onError(Throwable ex, boolean isOnCallback) {
                }

                @Override
                public void onCancelled(CancelledException cex) {
                }

                @Override
                public void onFinished() {
                }
            });
            I.e("JobSchedulerService", "[service api] finished");
        }catch (Exception e){
        } catch (Throwable throwable) {
        }*/

        // 返回true，很多工作都会执行这个地方
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        // 返回false来销毁这个工作
        return false;
    }

}