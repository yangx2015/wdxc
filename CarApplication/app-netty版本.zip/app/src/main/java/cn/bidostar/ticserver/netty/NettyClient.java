package cn.bidostar.ticserver.netty;

import android.os.SystemClock;

import cn.bidostar.ticserver.CarApplication;
import cn.bidostar.ticserver.utils.AppConsts;
import cn.bidostar.ticserver.utils.I;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;

/**
 * Created by admins on 2018/1/28.
 */

public class NettyClient {

    private static NettyClient nettyClient = new NettyClient();
    private EventLoopGroup group;
    private NettyListener listener;
    private Channel channel;
    private boolean isConnect = false;
    private int reconnectNum = Integer.MAX_VALUE;
    private long reconnectIntervalTime = 3000;
    public static NettyClient getInstance(){
        return nettyClient;
    }
    public synchronized NettyClient connect() {
        if (!isConnect) {
            group = new NioEventLoopGroup();
            Bootstrap bootstrap = new Bootstrap().group(group)
                    .option(ChannelOption.SO_KEEPALIVE,true)
                    .channel(NioSocketChannel.class)
                    .handler(new NettyClientInitializer(listener));
            try {
                bootstrap.connect(AppConsts.HOST, AppConsts.TCP_PORT).addListener(new ChannelFutureListener() {
                    @Override
                    public void operationComplete(ChannelFuture channelFuture) throws Exception {
                        if (channelFuture.isSuccess()) {
                            isConnect = true;
                            channel = channelFuture.channel();
                        } else {
                            isConnect = false;
                        }

                        CarApplication.getApplication().releaseWakeup();
                    }
                }).sync();
            } catch (Exception e) {
                I.e(e.getMessage());
                listener.onServiceStatusConnectChanged(NettyListener.STATUS_CONNECT_ERROR);
                reconnect();
            }
        }
        return this;
    }
    public void disconnect() {
        group.shutdownGracefully();
    }
    public void reconnect() {
        CarApplication.getApplication().lockWakeup();
        SystemClock.sleep(reconnectIntervalTime);
        I.e("重新连接");
        disconnect();
        connect();

    }
    public boolean sendMsgToServer(byte[] data, ChannelFutureListener listener) {
        //[C1,6,866401020000050,2018-11-06 08:20:11,T101,0000,0,9454006107013879,89462035031800077547,460,0,9375#4293#-63,100]
        boolean flag = channel != null && isConnect;
        if (flag) {
            ByteBuf buf = Unpooled.copiedBuffer(data);
            channel.writeAndFlush(buf).addListener(listener);
        }
        return flag;
    }
    public void setReconnectNum(int reconnectNum) {
        this.reconnectNum = reconnectNum;
    }
    public void setReconnectIntervalTime(long reconnectIntervalTime) {
        this.reconnectIntervalTime = reconnectIntervalTime;
    }
    public boolean getConnectStatus(){
        return isConnect;
    }
    public void setConnectStatus(boolean status){
        this.isConnect = status;
    }
    public void setListener(NettyListener listener) {
        this.listener = listener;
    }
}
