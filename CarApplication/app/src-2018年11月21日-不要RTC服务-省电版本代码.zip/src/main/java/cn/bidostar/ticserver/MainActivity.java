package cn.bidostar.ticserver;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import cn.bidostar.ticserver.service.SocketCarBindService;
import cn.bidostar.ticserver.utils.I;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //启动service，调整数据上报时长
        Intent serviceTwo = new Intent();
        serviceTwo.setClass(getApplicationContext(), SocketCarBindService.class);
        startService(serviceTwo);
        I.e("MainActivity","onCreate>>>>>");
    }

    @Override
    protected void onResume() {
        super.onResume();

        finish();
    }
}
